from rest_framework import serializers
from .models import Quiz,Question,QuizTakers,ResponsebyQuizTaker,Answer,Choice

class QuizSerializer(serializers.ModelSerializer):

    class Meta:
        model = Quiz
        fields = '__all__'

class QuestionSerializer(serializers.ModelSerializer):

    class Meta:
        model = Question
        fields = '__all__'

class QuizTakersSerializer(serializers.ModelSerializer):

    class Meta:
        model = QuizTakers
        fields = '__all__'

class ResponsebyQuizTakerSerializer(serializers.ModelSerializer):

    class Meta:
        model = ResponsebyQuizTaker
        fields = '__all__'

class AnswerSerializer(serializers.ModelSerializer):

    class Meta:
        model = Answer
        fields = '__all__'

class choiceSerializer(serializers.ModelSerializer):

    class Meta:
        model = Choice
        fields = '__all__'        