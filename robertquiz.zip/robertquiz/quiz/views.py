from django.shortcuts import render,get_object_or_404
import csv
from django.http import HttpResponse
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from .models import Quiz,Question,QuizTakers,ResponsebyQuizTaker,Answer,Choice
from .serializers import QuizSerializer,QuizTakersSerializer,QuestionSerializer,ResponsebyQuizTakerSerializer,AnswerSerializer,choiceSerializer

from rest_framework.authentication import TokenAuthentication,SessionAuthentication,BasicAuthentication
from rest_framework.permissions import IsAuthenticated, IsAdminUser
# Create your views here.

class QuizView(APIView):
    
    authentication_classes = [TokenAuthentication,SessionAuthentication,BasicAuthentication]
    #authentication_classes = [TokenAuthentication]
    permission_classes = [IsAuthenticated, IsAdminUser]
    
    def get(self,request):
        quizobj = Quiz.objects.all()
        serializer = QuizSerializer(quizobj,many=True)
        return Response(serializer.data)
    
    def post(self, request):
        serializer = QuizSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        
class QuizListDetail(APIView):

    authentication_classes = [TokenAuthentication,SessionAuthentication,BasicAuthentication]
    permission_classes = [IsAuthenticated, IsAdminUser]

    def get_object(self,id):
        try:
            return Quiz.objects.get(id=id)
        except student.DoesNotExist as e:
            return Response({'error':'Given studentId does not exist'},status=404)
    
    def get(self,request,id=None):
        instance = self.get_object(id)
        serializer = QuizSerializer(instance)
        return Response(serializer.data)

    def put(self,request,id=None):
        data = request.data
        instance = self.get_object(id)
        serializer = QuizSerializer(instance,data=data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=200)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        
class QuizTakerView(APIView):
    
    authentication_classes = [TokenAuthentication,SessionAuthentication,BasicAuthentication]
    permission_classes = [IsAuthenticated, IsAdminUser]
    
    def get(self,request):
        quizobj = QuizTakers.objects.all()
        serializer = QuizTakersSerializer(quizobj,many=True)
        return Response(serializer.data)
    
    def post(self, request):
        serializer = QuizTakersSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class QuestionView(APIView):
    
    authentication_classes = [TokenAuthentication,SessionAuthentication,BasicAuthentication]
    permission_classes = [IsAuthenticated, IsAdminUser]
    
    def get(self,request):
        quizobj = Question.objects.all()
        serializer = QuestionSerializer(quizobj,many=True)
        return Response(serializer.data)
    
    def post(self, request):
        serializer = QuestionSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        

class ResponsebyQuizTakerView(APIView):
    
    authentication_classes = [TokenAuthentication,SessionAuthentication,BasicAuthentication]
    permission_classes = [IsAuthenticated, IsAdminUser]
    
    def get(self,request):
        quizobj = ResponsebyQuizTaker.objects.all()
        serializer = ResponsebyQuizTakerSerializer(quizobj,many=True)
        return Response(serializer.data)
    
    def post(self, request):
        serializer = ResponsebyQuizTakerSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
class AnswerView(APIView):
    
    authentication_classes = [TokenAuthentication,SessionAuthentication,BasicAuthentication]
    permission_classes = [IsAuthenticated, IsAdminUser]
    
    def get(self,request):
        quizobj = Answer.objects.all()
        serializer = AnswerSerializer(quizobj,many=True)
        return Response(serializer.data)
    
    def post(self, request):
        serializer = AnswerSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class choiceView(APIView):
    
    authentication_classes = [TokenAuthentication,SessionAuthentication,BasicAuthentication]
    permission_classes = [IsAuthenticated, IsAdminUser]
    
    def get(self,request):
        quizobj = Choice.objects.all()
        serializer = choiceSerializer(quizobj,many=True)
        return Response(serializer.data)
    
    def post(self, request):
        serializer = choiceSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



# To save the scores of quiztaker
class csvscoreView(APIView):
    def get(self,request):
        quizobj = Quiz.objects.all()
        serializer = QuizSerializer(quizobj,many=True)
        #return Response(serializer.data)
        response = HttpResponse(serializer.data,content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="score.csv"'

        writer = csv.writer(response)
        scores = Library.objects.all().values_list('Quiztaker','score')
        for score in scores:
            writer.writerow(score)
        return response
      