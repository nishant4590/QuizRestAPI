from django.contrib import admin

# Register your models here.
from .models import Quiz,Question,QuizTakers,ResponsebyQuizTaker,Answer,Choice

admin.site.register(Quiz)
admin.site.register(Question)
admin.site.register(Answer)
admin.site.register(QuizTakers)
admin.site.register(ResponsebyQuizTaker)
admin.site.register(Choice)